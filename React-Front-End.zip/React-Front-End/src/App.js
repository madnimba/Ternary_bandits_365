import logo from './logo.svg';

import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { BrowserRouter as Router, Route, Routes} from 'react-router-dom';
import HomePage from './components/HomePage.js';
import MyProfile from './components/MyProfile.js';
import Login from './components/Login.js';
import ForgotPassword from './components/ForgotPassword.js';
import SignUp from './components/SignUp.js';
import PatientHomepage from './components/PatientHomepage.js';
import DailyChecklist from './components/DailyChecklist';

import './App.css';
import FindDoctor from './components/FindDoctor';


function App() {

  useEffect(() => {
    axios.get('/api/data')
      .then(response => {
        console.log(response.data);
      })
      .catch(error => {
        console.error(error);
      });
  }, []);


  return (


    
      <Router>
      <div className="App">

      
    

        <Routes>
          <Route exact path="/" element={<HomePage />} />
          <Route path="/login" element={<Login />} />
          <Route path="/forgot-password" element={<ForgotPassword />} />
          <Route path="/signup" element={<SignUp />} />
          <Route path="/patient-homepage" element={<PatientHomepage />} />
          <Route path="/my-profile" element={<MyProfile />} />
          <Route path="/find-doctor" element={<FindDoctor />} />
          <Route path="/daily-checklist" element={<DailyChecklist />} />

        </Routes>
      </div>
    </Router>
        






  );
}

export default App;


