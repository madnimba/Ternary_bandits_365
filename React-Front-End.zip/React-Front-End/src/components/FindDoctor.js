import React from 'react';
import "./views/findadoctor.css"

const FindDoctor = () => {
  const doctors = [
    {
      id: 1,
      name: 'Dr. John Smith',
      designation: 'Cardiologist',
      specialization: 'Heart Diseases',
      degrees: 'MD, PhD',
      experience: '15+ years',
      
    },
    {
      id: 2,
      name: 'Dr. Emily Johnson',
      designation: 'Dermatologist',
      specialization: 'Skin Disorders',
      degrees: 'MBBS, MD',
      experience: '10+ years',
      
    },
    // Add more doctors here...
  ];

  return (
    <div className="container">
      <h2>Find a Doctor</h2>
      <div className="doctor-cards">
        {doctors.map((doctor) => (
          <div className="doctor-card" key={doctor.id}>
            <img src="C:\Users\jarin\OneDrive\Documents\react\user-profile-website\src\components\d1.jpg"/>
            <h3>{doctor.name}</h3>
            <p>
              {doctor.designation}, {doctor.specialization}
            </p>
            <p>{doctor.degrees}</p>
            <p>{doctor.experience} of experience</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default FindDoctor;
