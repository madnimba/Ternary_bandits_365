import React, { useState } from 'react';
import "./views/myProfile.css"

const MyProfile = () => {
  const [isEditing, setIsEditing] = useState(false);

  const handleEditClick = () => {
    setIsEditing(true);
  };

  const handleUpdateClick = () => {
    setIsEditing(false);
  };

  return (
    <div className="container">
      <h2>My Profile</h2>
      <section>
        <label htmlFor="name">Name:</label>
        <input type="text" id="name" disabled={!isEditing} />
      </section>
      <section>
        <label>Sex:</label>
        <label htmlFor="female">
          <input type="radio" id="female" name="sex" disabled={!isEditing} /> Female
        </label>
        <label htmlFor="male">
          <input type="radio" id="male" name="sex" disabled={!isEditing} /> Male
        </label>
      </section>
      <section>
        <label htmlFor="height">Height:</label>
        <div className="input-container">
          <input type="number" id="height-ft" disabled={!isEditing} />
          <span>ft.</span>
          <input type="number" id="height-inches" disabled={!isEditing} />
          <span>inches</span>
        </div>
      </section>
      <section>
        <label htmlFor="weight">Weight:</label>
        <div className="input-container">
          <input type="number" id="weight" disabled={!isEditing} />
          <span>kg</span>
        </div>
      </section>
      <section>
        <label htmlFor="disease-history">History of Disease:</label>
        <textarea id="disease-history" disabled={!isEditing} />
      </section>
      <section>
        <label htmlFor="medicines">Medicines Taking Currently:</label>
        <textarea id="medicines" disabled={!isEditing} />
      </section>
      <section>
        <label htmlFor="supervising-doctor">Supervising Doctor:</label>
        <input type="text" id="supervising-doctor" disabled={!isEditing} />
      </section>
      <section className="button-section">
        {isEditing ? (
          <button onClick={handleUpdateClick} className="update-button">Update</button>
        ) : (
          <button onClick={handleEditClick} className="edit-button">Edit</button>
        )}
        <button className="health-profile-button">Health Profile</button>
      </section>
    </div>
  );
};

export default MyProfile;
