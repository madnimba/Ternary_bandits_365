import React from 'react';
import { Link } from 'react-router-dom';
import "./views/patientHome.css"

const PatientHomepage = () => {
  return (
    <div className="container">
      <h2>Patient Homepage</h2>
      <div className="button-container">
        <Link to="/my-profile" className="button">My Profile</Link>
        <Link to="/daily-checklist" className="button">Daily Checklist</Link>
        <Link to="/find-doctor" className="button">Find a Doctor</Link>
      </div>
    </div>
  );
};

export default PatientHomepage;