import React from 'react';
import "./views/homepage.css"
import { Link } from 'react-router-dom';

const HomePage = () => {
  return (
    <div>
      <h1>CareCheck!</h1>
      <button>
        <Link to="/login">I'm a Doctor</Link>
      </button>
      <button>
        <Link to="/login">I'm a Patient</Link>
      </button>
    </div>
  );
};

export default HomePage;
