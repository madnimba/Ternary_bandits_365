// import React from 'react';
// import "./views/login.css"
// import { Link } from 'react-router-dom';

// const Login = () => {
//   return (
//     <div>
//       <h2>Login</h2>
//       <form>
//         <input type="text" placeholder="Login ID / Email ID" />
//         <input type="password" placeholder="Password" />
//         <br></br>
//         <Link to="/patient-homepage" className="button">
//         <button type="submit">Login</button> </Link>
//       </form>
//       <div>
//         <Link to="/forgot-password">Forgot password?</Link>
//         <Link to="/signup">Sign up</Link>
//       </div>
//     </div>
//   );
// };

// export default Login;


import React from 'react';
import './views/login.css';
import { Link } from 'react-router-dom';

const Login = () => {
  return (
    <div className="login-container">
      <h2>Login</h2>
      <form>
        <input className="login-input" type="text" placeholder="Login ID / Email ID" />
        <input className="login-input" type="text" placeholder="Password" />
        <br />
        <Link to="/patient-homepage" className="button">
          <button className="login-button" type="submit">Login</button>
        </Link>
      </form>
      <div className="login-links">
        <Link to="/forgot-password">Forgot password?</Link>
        <Link to="/signup">Sign up</Link>
      </div>
    </div>
  );
};

export default Login;
