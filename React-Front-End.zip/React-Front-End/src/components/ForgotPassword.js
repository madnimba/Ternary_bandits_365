import React from 'react';

const ForgotPassword = () => {
  return (
    <div>
      <h2>Forgot Password</h2>
      {/* Add your forgot password form here */}
    </div>
  );
};

export default ForgotPassword;
