import React from 'react';

const SignUp = () => {
  return (
    <div>
      <h2>Sign Up</h2>
      {/* Add your sign up form here */}
    </div>
  );
};

export default SignUp;