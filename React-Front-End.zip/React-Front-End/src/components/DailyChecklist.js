import React, { useState } from 'react';
import "./views/dailychecklist.css"

const DailyChecklist = () => {
  const [morningMedicine, setMorningMedicine] = useState('');
  const [noonMedicine, setNoonMedicine] = useState('');
  const [nightMedicine, setNightMedicine] = useState('');
  const [nextCheckupDate, setNextCheckupDate] = useState('');

  const handleMorningMedicineChange = (event) => {
    setMorningMedicine(event.target.value);
  };

  const handleNoonMedicineChange = (event) => {
    setNoonMedicine(event.target.value);
  };

  const handleNightMedicineChange = (event) => {
    setNightMedicine(event.target.value);
  };

  const handleNextCheckupDateChange = (event) => {
    setNextCheckupDate(event.target.value);
  };

  return (
    <div className="container">
      <h2>Daily Checklist</h2>
      <section>
        <h3>Medicines for Today</h3>
        <div className="medicines-section">
          <div>
            <label htmlFor="morning-medicine">Morning:</label>
            <input
              type="text"
              id="morning-medicine"
              value={morningMedicine}
              onChange={handleMorningMedicineChange}
              className="large-input"
            />
          </div>
          <div>
            <label htmlFor="noon-medicine">Noon:</label>
            <input
              type="text"
              id="noon-medicine"
              value={noonMedicine}
              onChange={handleNoonMedicineChange}
              className="large-input"
            />
          </div>
          <div>
            <label htmlFor="night-medicine">Night:</label>
            <input
              type="text"
              id="night-medicine"
              value={nightMedicine}
              onChange={handleNightMedicineChange}
              className="large-input"
            />
          </div>
        </div>
      </section>
      <section>
        <h3>Next Checkup Date</h3>
        <input
          type="text"
          value={nextCheckupDate}
          onChange={handleNextCheckupDateChange}
          className="large-input"
        />
      </section>
    </div>
  );
};

export default DailyChecklist;
